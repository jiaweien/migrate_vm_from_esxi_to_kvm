#!/bin/bash

sys_disk_file=$1
nbd_serial=$2

current_path=$(pwd)
auto_process_log=${current_path}/process_automatical.log
[ ! -z "${nbd_serial}" ] || nbd_serial="nbd11"

err_process(){
    cd ${current_path} && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1
}

# win03 qemu-nbd -c /dev/${nbd_serial} -P 1 XXXX
# win08 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX && qemu-nbd -c /dev/${nbd_serial} -P 1 XXXX
# win12 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
if [ -z "${sys_disk_file}" -o ! -f "${sys_disk_file}" ]
then
    echo "param error" >> ${auto_process_log}
    err_process
    exit 1 
fi

qemu-nbd -d /dev/${nbd_serial} &>/dev/null
qemu-nbd -c /dev/${nbd_serial} -P 2 ${sys_disk_file} -f raw &>/dev/null
if [ $? -ne 0 ]
then
    echo "exec qemu-nbd -c error" >> ${auto_process_log}
    err_process
    exit 1
fi

#ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
[ -d "./sys" ] || mkdir ./sys >/dev/null 2>&1
mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    echo "exec mount error" >> ${auto_process_log}
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -o re -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error first!" >> ${auto_process_log}
        err_process
        exit 1
    fi
fi

#check read-only mounted
touch ./sys/.111222333 >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    touch ./sys/111222333 >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error second!" >> ${auto_process_log}
        err_process
        exit 1
    fi
fi
rm -f ./sys/.111222333 >/dev/null 2>&1

\cp -r ./install_cert_and_virtio ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "cp drivers file into guest machine error" >> ${auto_process_log}
    err_process
    exit 1
fi

#if bat exec failed , use cmd.exe modify the administrator password and logon
cd ./sys/Windows/System32/config && \cp ./SAM ./SAM.ori >/dev/null 2>&1
hivexregedit --merge ./SOFTWARE ../../../../scripts.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 0 error" >> ${auto_process_log}
    err_process
    exit 1
fi

hivexregedit --merge ./SOFTWARE ../../../../driver_path.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 2 error" >> ${auto_process_log}
    err_process
    exit 1
fi

hivexregedit --merge ./SOFTWARE ../../../../winlogon.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 3 error" >> ${auto_process_log}
    err_process
    exit 1
fi

hivexregedit --merge ./SYSTEM ../../../../remove_disk_check.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "remove windows guest disk auto check error" >> ${auto_process_log}
    #err_process
    #exit 1
fi

#modify script by dynamic which need execute in vm for uninstall "VMware Tools" procedure
productcode=`hivexregedit --export ./SOFTWARE  '\Microsoft\Windows\CurrentVersion\Uninstall' | grep -i "56,00,4d,00,77,00,61,00,72,00,65,00,20,00,54,00,6f,00,6f,00,6c,00,73,00" -B 20 | grep "^\[" | tail -n 1 | awk -F '{' '{print $2}' | awk -F '}' '{print $1}'`
if [ -z "${productcode}" ]
then
    echo "get VMware Tools product code err" >> ${auto_process_log}
    err_process
    exit 1
fi
insert_record='C:\\windows\\System32\\msiexec.exe /uninstall '"{${productcode}}"' /quiet /n /norestart >>C:\\install_cert.log 2>&1\r'
sed -i "/.\qemu-ga-x86/a\\${insert_record}" ../../../install_cert_and_virtio/tools/install_cert.bat >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "dynamic modify windows script error" >> ${auto_process_log}
    err_process
    exit 1
fi

sed -i "/.\qemu-ga-x86/a\\${insert_record}" ../../../install_cert_and_virtio/tools/install_cert.bat >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "dynamic modify windows script error" >> ${auto_process_log}
    err_process
    exit 1
fi

cd ../drivers/ && mkdir virtio >/dev/null 2>&1
\cp ../../../../install_cert_and_virtio/virtio_driver_file/* ./virtio > /dev/null 2>&1 && \cp ./virtio/*.sys ./ >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "inject virtio driver files into windows guest error" >> ${auto_process_log}
    err_process
    exit 1
fi

cd ../ &>/dev/null
[ -d vmtool_deploy_bak ] || mkdir vmtool_deploy_bak &>/dev/null
\cp vmGuestLib.dll ./vmtool_deploy_bak &>/dev/null
\cp vmGuestLibJava.dll ./vmtool_deploy_bak &>/dev/null
\cp vsocklib.dll ./vmtool_deploy_bak &>/dev/null

cd ../SysWOW64 &>/dev/null
[ -d vmtool_deploy_bak ] || mkdir vmtool_deploy_bak &>/dev/null
\cp msvcr71.dll ./vmtool_deploy_bak &>/dev/null
\cp vmGuestLib.dll ./vmtool_deploy_bak &>/dev/null
\cp vmGuestLibJava.dll ./vmtool_deploy_bak &>/dev/null
\cp vsocklib.dll ./vmtool_deploy_bak &>/dev/null

\cp -r ../../Program\ Files/VMware/VMware\ Tools/ ../../Program\ Files/VMware/VMware\ Tools_bak/ &>/dev/null
cd ../../../ && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1

#The purpose of the following code is to enable the Windows startup process to skip the selection of repair options
#If execute error, ignore and exit successfully
#If error, there will be a chance to boot automatically into the repair options
#On the occasion, the vm will be can not ping and can not find arp info in arp data file, the migrate will be false
#add on 20200121
qemu-nbd -c /dev/${nbd_serial} -P 1 ${sys_disk_file} -f raw &>/dev/null
if [ $? -ne 0 ]
then
    echo "exec qemu-nbd -c error" >> ${auto_process_log}
    err_process
    exit 0
fi

mount /dev/${nbd_serial} ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "exec mount error" >> ${auto_process_log}
    err_process
    exit 0
fi

if [ -f "./sys/Boot/BCD" ]
then
    hivexregedit --merge ./sys/Boot/BCD ./bcd_config.reg &>> ${auto_process_log} 
    if [ $? -ne 0 ]
    then
        echo "modify windows guest registry 0 error" >> ${auto_process_log}
        err_process
        exit 0
    fi
else
    echo "the BCD file is not exist" >> ${auto_process_log}
    err_process
    exit 0
fi

umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>>${auto_process_log}
echo "success" >> ${auto_process_log}
