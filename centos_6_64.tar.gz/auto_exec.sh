#!/bin/bash

sys_disk_file=$1
nbd_serial=$2

current_path=$(pwd)
[ ! -z "${nbd_serial}" ] || nbd_serial="nbd11"

err_process(){
    cd ${current_path} && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1
}

# win03 qemu-nbd -c /dev/${nbd_serial} -P 1 XXXX
# win08 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
# centos 6.x qemu-nbd -c /dev/${nbd_serial} -P 3 XXXX
if [ -z "${sys_disk_file}" -o ! -f "${sys_disk_file}" ]
then
    echo "param error" 
    err_process
    exit 1 
fi

qemu-nbd -d /dev/${nbd_serial} &>/dev/null
qemu-nbd -c /dev/${nbd_serial} -P 3 ${sys_disk_file} -f raw &>/dev/null
if [ $? -ne 0 ]
then
    echo "exec qemu-nbd -c error"
    err_process
    exit 1
fi

blk_file_system=$(blkid /dev/${nbd_serial} | awk -F "TYPE=" '{print $2}' | sed -e "s/\"//g" 2>/dev/null)
#ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
[ -d "./sys" ] || mkdir ./sys >/dev/null 2>&1
mount /dev/${nbd_serial} ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    echo "exec mount error"
    if [ ! -z "${blk_file_system}" ]
    then
        fsck.${blk_file_system} /dev/${nbd_serial} &>/dev/null
        mount -o re /dev/${nbd_serial} ./sys >/dev/null 2>&1
        if [ $? -ne 0 ]
        then
            echo "remount system block read-write first error after fsck.${blk_file_system}"
            err_process
            exit 1
        fi
    else
        echo "get ${sys_disk_file} file system error"
        err_process
        exit 1
    fi
fi

#check read-only mounted
touch ./sys/.111222333 >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    fsck.${blk_file_system} /dev/${nbd_serial} >/dev/null 2>&1
    mount /dev/${nbd_serial} ./sys >/dev/null 2>&1
    touch ./sys/111222333 >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write second error after fsck.${blk_file_system}"
        #unlock root directory
        chattr -R -ia ./sys &>/dev/null
        touch ./sys/.111222333 >/dev/null 2>&1
        if [ $? -ne 0 ]
        then
            echo "change directory attr of sys error after fsck.${blk_file_system}"
            err_process
            exit 1
        fi
    fi
fi
rm -f ./sys/.111222333 >/dev/null 2>&1

#if not deleted , the vm netcard name will be begin with eth2 or bigger 
if [ -f "./sys/etc/udev/rules.d/70-persistent-net.rules" ]
then
    mv ./sys/etc/udev/rules.d/70-persistent-net.rules ./sys/tmp &>/dev/null
    if [ $? -ne 0 ]
    then
        echo "delete centos 6 70-persistent-net.rules file error"
        err_process
        exit 1
    fi
fi

#modify user ifcfg from ifcfg-eth0 , and use dhcp
ls ./sys/etc/sysconfig/network-scripts/ifcfg-eth* &>/dev/null
if [ $? -eq 0 ]
then
    rm -f ./sys/etc/sysconfig/network-scripts/ifcfg-eth* &>/dev/null &&  mv ./ifcfg-eth0 ./sys/etc/sysconfig/network-scripts/ &>/dev/null
    if [ $? -ne 0 ]
    then
        echo "upgrade user's vm ifcfg file error"
        err_process
        exit 1
    fi
else
    mv ./ifcfg-eth0 ./sys/etc/sysconfig/network-scripts/ &>/dev/null
    if [ $? -ne 0 ]
    then
        echo "upgrade user's vm ifcfg file error"
        err_process
        exit 1
    fi
fi

#if not do this , it's can not startup on transfer machine
if [ -f "./sys/etc/fstab" ]
then
    sed -i -e "s/.db/vdb/" ./sys/etc/fstab &>/dev/null
fi

#if not do this , it's can not change password
if [ -f "./sys/etc/selinux/config" ]
then
    grep -i "selinux=disabled" ./sys/etc/selinux/config | grep -v "^#" &>/dev/null
    if [ $? -ne 0 ]
    then
        selinux_str=$(grep -i "selinux=" ./sys/etc/selinux/config | grep -v "^#" | tail -n 1)
        #if user have delete selinux option in config... so do not use this commented out code
        #if [ -z "${selinux_str}" -o $? -ne 0 ]
        #then
        #    echo "can not find selinux config option in /etc/selinux/config file in vm system"
        #    err_process
        #    exit 1
        #fi
        if [ ! -z "${selinux_str}" ]
        then
            sed -i -e "s/${selinux_str}/SELINUX=disabled/" ./sys/etc/selinux/config &>/dev/null
            if [ $? -ne 0 ]
            then
                echo "reconfig selinux disabled error"
                err_process
                exit 1
            fi
        else
            echo "SELINUX=disabled" >> ./sys/etc/selinux/config 2>/dev/null
            if [ $? -ne 0 ]
            then
                echo "reconfig selinux disabled error"
                err_process
                exit 1
            fi
        fi
    fi
fi

umount ./sys &>/dev/null && qemu-nbd -d /dev/${nbd_serial} &>/dev/null
#virt-win-reg --merge ${sys_disk_file} ./xinnet-linux.reg >/dev/null 2>&1
#if [ $? -ne 0 ]
#then
#    echo "modify windows guest registry error"
#    exit 1
#fi

#echo "success"
