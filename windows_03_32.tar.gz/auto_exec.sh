#!/bin/bash

sys_disk_file=$1
nbd_serial=$2

current_path=$(pwd)
[ ! -z "${nbd_serial}" ] || nbd_serial="nbd11"

err_process(){
    cd ${current_path} && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1
}

# win03 qemu-nbd -c /dev/${nbd_serial} -P 1 XXXX
# win08 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
# win12 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
if [ -z "${sys_disk_file}" -o ! -f "${sys_disk_file}" ]
then
    echo "param error" 
    err_process
    exit 1 
fi

qemu-nbd -d /dev/${nbd_serial} &>/dev/null
qemu-nbd -c /dev/${nbd_serial} -P 1 ${sys_disk_file} -f raw &>/dev/null
if [ $? -ne 0 ]
then
    echo "exec qemu-nbd -c error"
    err_process
    exit 1
fi

#ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
[ -d "./sys" ] || mkdir ./sys >/dev/null 2>&1
mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    echo "exec mount error"
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -o re -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error first!"
        err_process
        exit 1
    fi
fi

#check read-only mounted
touch ./sys/.111222333 >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    touch ./sys/111222333 >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error second!"
        err_process
        exit 1
    fi
fi
rm -f ./sys/.111222333 >/dev/null 2>&1

\cp -r ./install_cert_and_virtio ./sys/ >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "cp drivers file into guest machine error"
    err_process
    exit 1
fi

if [ -f "./sys/WINDOWS/system32/cmd.exe" ]
then
    mv -f ./sys/WINDOWS/system32/cmd.exe ./sys/WINDOWS/system32/cmd.exe.ori >/dev/null 2>&1
    \cp ./cmd.exe ./sys/WINDOWS/system32/ >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "copy foreigh cmd.exe err"
        err_process
        exit 1
    fi
else
    echo "current windows don't have cmd.exe"
    err_process
    exit 1
fi

#if bat exec failed , use cmd.exe modify the administrator password and logon
cd ./sys/WINDOWS/system32/config && \cp ./SAM ./SAM.ori >/dev/null 2>&1
hivexregedit --merge ./software ../../../../scripts.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 0 error"
    err_process
    exit 1
fi

hivexregedit --merge ./software ../../../../system.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 1 error"
    err_process
    exit 1
fi

hivexregedit --merge ./system ../../../../win_2003_32.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 2 error"
    err_process
    exit 1
fi

hivexregedit --merge ./software ../../../../driver_path.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows guest registry 3 error"
    err_process
    exit 1
fi

hivexregedit --merge ./software ../../../../winlogon.reg >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "modify windows shutdownbeforelogon registry 4 error"
    err_process
    exit 1
fi

#modify script by dynamic which need execute in vm for uninstall "VMware Tools" procedure
productcode=`hivexregedit --export ./software  '\Microsoft\Windows\CurrentVersion\Uninstall' | grep -i "56,00,4d,00,77,00,61,00,72,00,65,00,20,00,54,00,6f,00,6f,00,6c,00,73,00" -B 20 | grep "^\[" | tail -n 1 | awk -F '{' '{print $2}' | awk -F '}' '{print $1}' 2>/dev/null`
if [ -z "${productcode}" ]
then
    echo "get VMware Tools product code err"
    err_process
    exit 1
fi
insert_record='C:\\windows\\system32\\msiexec.exe /uninstall '"{${productcode}}"' /quiet /n /norestart >nul 2>nul\r'
sed -i "/.\qemu-ga-x86/a\\${insert_record}" ../../../install_cert_and_virtio/tools/install_cert.bat >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "dynamic modify windows script error"
    err_process
    exit 1
fi

sed -i "/.\qemu-ga-x86/a\\${insert_record}" ../../../install_cert_and_virtio/tools/install_cert.bat >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "dynamic modify windows script error"
    err_process
    exit 1
fi

cd ../drivers/ && mkdir virtio >/dev/null 2>&1
\cp ../../../../install_cert_and_virtio/virtio_driver_file/* ./virtio > /dev/null 2>&1 && \cp ./virtio/*.sys ./ >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "inject virtio driver files into windows guest error"
    err_process
    exit 1
fi

cd ../ &>/dev/null
[ -d vmtool_deploy_bak ] || mkdir vmtool_deploy_bak &>/dev/null
\cp tprdpw32.dll ./vmtool_deploy_bak &>/dev/null
\cp TPSvc.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMondeu.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMon.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMonjpn.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMonUIdeu.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMonUI.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMMonUIjpn.dll ./vmtool_deploy_bak &>/dev/null
\cp TPVMW32.dll ./vmtool_deploy_bak &>/dev/null
\cp msvcr71.dll ./vmtool_deploy_bak &>/dev/null
\cp vmGuestLib.dll ./vmtool_deploy_bak &>/dev/null
\cp vmGuestLibJava.dll ./vmtool_deploy_bak &>/dev/null
\cp VMUpgradeAtShutdownWXP.dll ./vmtool_deploy_bak &>/dev/null
\cp vsocklib.dll ./vmtool_deploy_bak &>/dev/null

\cp -r ../../Program\ Files/VMware/VMware\ Tools/ ../../Program\ Files/VMware/VMware\ Tools_bak/ &>/dev/null
cd ../../../ && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1

#virt-win-reg --merge ${sys_disk_file} ./xinnet-linux.reg >/dev/null 2>&1
#if [ $? -ne 0 ]
#then
#    echo "modify windows guest registry error"
#    exit 1
#fi

#echo "success"
