#!/bin/bash

sys_disk_file=$1
nbd_serial=$2

current_path=$(pwd)
[ ! -z "${nbd_serial}" ] || nbd_serial="nbd11"

err_process(){
    cd ${current_path} && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1
}

# win03 qemu-nbd -c /dev/${nbd_serial} -P 1 XXXX
# win08 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
# win12 qemu-nbd -c /dev/${nbd_serial} -P 2 XXXX
if [ -z "${sys_disk_file}" -o ! -f "${sys_disk_file}" ]
then
    echo "param error" 
    err_process
    exit 1 
fi

qemu-nbd -d /dev/${nbd_serial}
qemu-nbd -c /dev/${nbd_serial} -P 1 ${sys_disk_file} -f raw
if [ $? -ne 0 ]
then
    echo "exec qemu-nbd -c error"
    err_process
    exit 1
fi

#ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
[ -d "./sys" ] || mkdir ./sys >/dev/null 2>&1
mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "exec mount error"
    umount ./sys
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -o re -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error!"
        err_process
        exit 1
    fi
fi

#check read-only mounted
touch ./sys/.111222333 >/dev/null 2>&1
if [ $? -ne 0 ]
then
    umount ./sys>/dev/null 2>&1
    ntfsfix /dev/${nbd_serial} >/dev/null 2>&1
    mount -t ntfs /dev/${nbd_serial} ./sys >/dev/null 2>&1
    touch ./sys/111222333 >/dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "remount system block read-write error!"
        err_process
        exit 1
    fi
fi
rm -f ./sys/.111222333 >/dev/null 2>&1

#if bat exec failed , use cmd.exe modify the administrator password and logon
cd ./sys/WINDOWS/system32/config && \cp ./SAM ./SAM.123 && \cp ./SAM.ori ./SAM >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "replace windows SAM file error"
    err_process
    exit 1
fi

mv -f ../cmd.exe ../cmd.exe.foreign >/dev/null 2>&1 && mv -f ../cmd.exe.ori ../cmd.exe >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "recover windows cmd.exe error"
    err_process
    exit 1
fi

cd ../../../ >/dev/null 2>&1 && rm -rf install_cert_and_virtio/ > /dev/null 2>&1 && rm -f install*.log >/dev/null 2>&1
if [ $? -ne 0 ]
then
    echo "clean virtio driver files and tools error"
    err_process
    exit 1
fi

#\cp -r ../drivers/virtio ../install_cert_and_virtio/virtio_driver_file &>/dev/null

cd ../ && umount ./sys && qemu-nbd -d /dev/${nbd_serial} >/dev/null 2>&1

echo "success"
